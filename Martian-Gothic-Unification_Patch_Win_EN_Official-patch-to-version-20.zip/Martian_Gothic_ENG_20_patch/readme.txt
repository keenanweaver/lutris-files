Martian Gothic: Unification
---------------------------

patch #2

company: Talonsoft (www.talonsoft.com)

homesite: unknown

This patch will work with previous savegames. It can also be applied 
on top of your original installation or over Martian Gothic patch 1. 
Run mgpatch2.exe to install.

To see if your patch installation has been successful you can check 
the patch.txt file in the installation directory of the game 
(c:\program files\talonsoft\martian gothic by default). This file 
lists any patches successfully installed. 

Issues addressed by Martian Gothic Patch 2:

- Fixed further bugs reported on the message boards at
  http://www.talonsoft.com/martiangothic/index.html Many thanks to 
  all who contributed there. 
- Improved collision and detection with the floor and environment 
  (again). 
- Fixed crashes in the Necropolis area. 
- Extrude (aka 'spiders') behaviour, generation and combat has been
  dramatically improved and bug associated with them jumping on your 
  face fixed. 
- Cheats incorporated (watch this space!). 
- Fixed two issues involving the scene where your character is being 
  winched down over the alien tomb.
- Fixed a problem with objects which could themselves be containers 
  (e.g. babybug/weedkiller gun). 
- Greatly improved the grapple and combat with the Nondead. 
- Fixed a problem found with shooting at Nondead when other 'dead' 
  bodies lay in front of them. 
- Fixed problem causing a crash when using the Laser Scalpel on the 
  Jammed Door near Kremlin. 
- Ben Gunn is now more co-operative and you can radio him to help 
  you when you have been poisoned by the extrudes. 
- Shooting extrudes is improved so that combat with them is more 
  dynamic. 
- Getting attacked off screen works better. 
- Salem Dorm's Trimorph has improved AI. 
- Shuttle Bay doors opening from Zen Garden now has cut scene. 
- Whittaker's cut scene (man on Mars) improved. 

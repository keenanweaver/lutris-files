The Thing US PC Mouse Look Patch (1.2)


Table of Contents
-----------------

1.  Patch Information
    1.1 (Patch Requirements)

2.  Patch Instructions
3.  Technical/Customer Support



1.  Patch Information
---------------------

This patch for the US PC version of The Thing adds a mouse-look option to the game.  To 
use the mouse look option, enter the Options menu, then Advanced Controls, and turn the 
Mouse-Look option ON.


1.1 Patch Requirements
----------------------

Before you install this patch, you must have installed the 1.1 patch 
"blg_thething_patch_10_11.exe". That patch may be included in this .zip if you downloaded 
"blg_thething_patch_10_12.zip".  If you only downloaded the 1.2 mouse look patch, you can
find the first patch at http://www.thethinggames.com.


2.  Patch Instructions
----------------------

This patch is a self extracting, self installing executable.  Simply run the executable 
and wait for the patch to finish installing itself.


3.  Technical/Customer Support
------------------------------

If you experience any problems after running the patch, please contact Customer Support 
using the information in your game manual.


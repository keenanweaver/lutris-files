The Thing

US Build 9 - US Build 13 Patch (1.1)

This patch is a self extractable binary. Simply run the executable, and it will 
autodetect The Thing and patch it.

This patch contains several fixes for minor bugs.  If you experience any problems after 
running the patch, please contact Technical Support using the information in your game 
manual.

Martian Gothic: Unification
generic fixer by EOD //[UCF]

It fixes memory access violation during initialization of the game.

"Generic" means that it will work on different versions of "martian gothic.exe" files.

Read techinfo.txt if you want to know what was done.

Enjoy!